from .modulo_soma import funcao_soma as soma


__all__ = ["soma", ]
