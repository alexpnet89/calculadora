def funcao_soma(valor_a: int, valor_b: int) -> int:
    return valor_a + valor_b
